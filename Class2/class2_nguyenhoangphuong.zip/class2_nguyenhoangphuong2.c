#include<stdio.h>
#include<math.h>

int main()

{
	int s, m=3,n=5, r=0,t=0;
	float x=3.0,y=0;
	
	t=n/m;
	printf("\n t=%d",t);
	
	r=n%m;
	printf("\n r=%d",r);
	
	y=(float)n/m;
	printf("\n y=%f",y);
	
	t=x*y-m/2;
	printf("\n t=%d",t);
	
	x=x*2.0;
	printf("\n x=%f",x);
	
	s=(m+n)/r;
	printf("\n s=%d",s);
	
	y=--n;
	printf("\n y=%f",y);
	
	return 0;
}
	
	
	
	
	
