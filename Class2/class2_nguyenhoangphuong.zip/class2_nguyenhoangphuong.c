#include<stdio.h>
#include<math.h>

int main()
{
	float cm, inch , feet;
	
	cm=0;
	inch=0;
	feet=0;
	
	printf("\n Please enter the number you want to convert:");
	scanf("%f",&cm);
	
	inch= (cm*0.39);
	printf("\n inch = %.1f",inch);
	
	feet=( cm *30.48 );
	printf("\n feet =%.1f",feet);
	
	return 0 ;
}

