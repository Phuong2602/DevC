#include<stdio.h>
#include<math.h>

int main()
{
	int number=10,i=0;
	
	printf("\nEnter your number to calculate:");
	scanf("%d",&number);
	
	for(i=0;i<=number;i++)
	
	{
		printf("%d*%d=%d\n",number,i,number*i);
		
		
	}	
	printf("\n");
	return 0;
}
